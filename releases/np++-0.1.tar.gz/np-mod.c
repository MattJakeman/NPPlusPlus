/*
Copyright (c) 2009, Matthew Jakeman
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the <organization> nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include <linux/module.h>	/* Needed by all modules */
#include <linux/kernel.h>	/* Needed for KERN_INFO */
#include <linux/init.h>		/* Needed for the macros */
#include <linux/netfilter.h>
#include <linux/netfilter_ipv6.h>
#include <linux/netdevice.h>
#include <linux/kobject.h>
#include <linux/sysfs.h>
#include <linux/version.h>
#include "np-mod.h"

#define DRIVER_AUTHOR "Matthew Jakeman <m.jakeman@lancaster.ac.uk>"
#define DRIVER_DESC   "NP++ Module"

MODULE_LICENSE("GPL");

MODULE_AUTHOR(DRIVER_AUTHOR);
MODULE_DESCRIPTION(DRIVER_DESC);

/*
* NP++ Globals
*/
//u_char np_physx[NP_PHYS_MAX];
struct npstats np_stats;

/*
* Netfilter Structs
*/
static struct nf_hook_ops np_in_hook_ops =
{
	.list = { NULL, NULL },
	.hook = np_input,
	.pf = PF_INET6,
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,24)
	.hooknum = NF_INET_LOCAL_IN
#else
	.hooknum = NF_IP6_LOCAL_IN
#endif
};

static struct nf_hook_ops np_for_hook_ops =
{
    .list = { NULL, NULL },
    .hook = np_input,
    .pf = PF_INET6,
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,24)
    .hooknum = NF_INET_FORWARD
#else
	.hooknum = NF_IP6_FORWARD
#endif
};

static struct nf_hook_ops np_out_hook_ops =
{
	.list = { NULL, NULL },
	.hook = np_output,
	.pf = PF_INET6,
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,24)
	.hooknum = NF_INET_POST_ROUTING
#else
	.hooknum = NF_IP6_POST_ROUTING
#endif
};

static void init_np_stats(void)
{
	np_stats.p_sent = 0;
	np_stats.p_recvd = 0;
	np_stats.p_in_dropped = 0;
	np_stats.p_out_dropped = 0;
}

/*
* NP++ Initialisation Function
*/
unsigned int np_init(void)
{
	nf_register_hook(&np_in_hook_ops);
	nf_register_hook(&np_for_hook_ops);
	nf_register_hook(&np_out_hook_ops);
	init_np_stats();
/*
	for(i = 0 ; i < NP_PHYS_MAX ; i++)
	{
		np_physx[i] = NP_PHYS_UNSUPPORTED;
	}
*/
	return 0;
}

/*
* NP++ Input Processing
*/
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,23)
unsigned int np_input(unsigned int hook, struct sk_buff *pskb,
               const struct net_device *indev, const
               struct net_device *outdev, int
               (*okfn)(struct sk_buff *))
#else
unsigned int np_input(unsigned int hook, struct sk_buff **pskb,
               const struct net_device *indev, const
               struct net_device *outdev, int
               (*okfn)(struct sk_buff *))
#endif
{
	struct np_int_map *npim;
    struct list_head *pos, *q,  *pos2, *q2;
	struct np_sw *nps;

    /*
    * Clean up each interfaces proc_directory_entries
    */
    list_for_each_safe(pos, q, &ifcm_pdes.npil)
	{
		npim = list_entry(pos, struct np_int_map, npil);
		if(npim->ndp && npim->ndp->ifindex == indev->ifindex)
		{
			list_for_each_safe(pos2, q2, &np_phys_sw.npswl)
			{
				nps = list_entry(pos2, struct np_sw, npswl);
				if(nps->phy_id == npim->map)
				{
#ifdef DEBUG
					printk(KERN_INFO "Receiving packet using %s\n", nps->desc);
#endif

#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,23)
					nps->phy_input(&pskb, indev);
#else
					nps->phy_input(pskb, indev);
#endif
					nps->p_recvd++;
					np_stats.p_recvd++;
					return NF_ACCEPT;
				}
			}
		}
	}
	np_stats.p_in_dropped++;
	return NF_DROP;
}

/*
* NP++ Output Processing
*/
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,23)
unsigned int np_output(unsigned int hook, struct sk_buff *pskb,
               const struct net_device *indev, const
               struct net_device *outdev, int
               (*okfn)(struct sk_buff *))
#else
unsigned int np_output(unsigned int hook, struct sk_buff **pskb,
               const struct net_device *indev, const
               struct net_device *outdev, int
               (*okfn)(struct sk_buff *))
#endif
{
	struct np_int_map *npim;
    struct list_head *pos, *q,  *pos2, *q2;
	struct np_sw *nps;

    list_for_each_safe(pos, q, &ifcm_pdes.npil)
	{
		npim = list_entry(pos, struct np_int_map, npil);
		if(npim->ndp && npim->ndp->ifindex == outdev->ifindex)
		{
			list_for_each_safe(pos2, q2, &np_phys_sw.npswl)
			{
				nps = list_entry(pos2, struct np_sw, npswl);
				if(nps->phy_id == npim->map)
				{
#ifdef DEBUG
					printk(KERN_INFO "Sending packet using %s\n", nps->desc);
#endif

#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,23)
					nps->phy_output(indev, pskb);
#else
					nps->phy_output(indev, *pskb);
#endif
					nps->p_sent++;
					np_stats.p_sent++;
					return NF_ACCEPT;
				}
			}
		}
	}
	np_stats.p_out_dropped++;
	return NF_DROP;
}

int init_module(void)
{
#ifdef DEBUG
	printk(KERN_INFO "Loading NP++ Kernel Module\n");
#endif

	np_init();
	np_procfs_init();
	mappings_init();

#ifdef DEBUG
	printk(KERN_INFO "Finished Loading NP++ Module\n");
#endif
	return 0;
}


void cleanup_module(void)
{
#ifdef DEBUG
	printk(KERN_INFO "Removing NP++ Kernel Module\n");
#endif
	/*
	* Unregister Netfilter Hooks
	*/
	nf_unregister_hook(&np_in_hook_ops);
	nf_unregister_hook(&np_for_hook_ops);
	nf_unregister_hook(&np_out_hook_ops);

	np_procfs_cleanup();
#ifdef DEBUG
	printk(KERN_INFO "NP++ Module Succesfully removed\n");
#endif
}

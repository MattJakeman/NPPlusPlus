/*
Copyright (c) 2009, Matthew Jakeman
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the <organization> nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#define EXPORT_SYMTAB
/*
* Maximum number of allowed physical mappings
*/
#define NP_PHYS_MAX 256

/*
* NP++ default physical mapping identifier
*/
#define NP_PHYS_DEFAULT 0

/*
* NP++ unsupported physical mapping identifier
*/
#define NP_PHYS_UNSUPPORTED 1

/*
* Proc stuff
*/
#define PROC_BUF_SIZE 16

#define DEBUG

struct npstats
{
	long p_sent;
	long p_recvd;
	long p_in_dropped;
	long p_out_dropped;
};

extern struct npstats np_stats;


extern struct proc_dir_entry *np_pde;
extern struct proc_dir_entry *np_ifcurmapping_pde;

struct np_int_map
{
	struct list_head npil;
	struct proc_dir_entry *int_pde;
	char name[IFNAMSIZ];
	struct net_device *ndp;
	u_char map;
};

extern struct np_int_map ifcm_pdes;

struct np_sw
{
    struct list_head npswl; // Used for linked list
    u_char phy_id; // ID of the mapping
    const char *desc; // Textual Description
    int (*phy_input) (struct sk_buff **, const struct net_device *); // Input Function
    struct sk_buff *(*phy_output) (const struct net_device *, struct sk_buff *); // Output function
    void (*phy_slowtimo) (void) ; // Timeout Function (Not Yet Implemented)
    /*
    * Counters
    */
    long p_sent;   //Packets Sent
    long p_recvd;  //Packets Received
    long p_in_dropped; //Incoming Packets Dropped
    long p_out_dropped; //Outgouing Pacjets Dropped
};

extern struct np_sw np_phys_sw;
/*
* NP++ Functions
*/
unsigned int np_init(void);

#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,23)
unsigned int np_input(unsigned int hook, struct sk_buff *pskb,
               const struct net_device *indev, const
               struct net_device *outdev, int
               (*okfn)(struct sk_buff *));
#else
unsigned int np_input(unsigned int hook, struct sk_buff **pskb,
               const struct net_device *indev, const
               struct net_device *outdev, int
               (*okfn)(struct sk_buff *));
#endif

#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,23)
unsigned int np_output(unsigned int hook, struct sk_buff *pskb,
               const struct net_device *indev, const
               struct net_device *outdev, int
               (*okfn)(struct sk_buff *));
#else
unsigned int np_output(unsigned int hook, struct sk_buff **pskb,
               const struct net_device *indev, const
               struct net_device *outdev, int
               (*okfn)(struct sk_buff *));
#endif

/*
* np-procfs.c functions
*/
int np_procfs_init(void);
int np_procfs_cleanup(void);
int ifcurmapping_write(struct file *filp, const char __user *buff, unsigned long len, void *data);
int ifcurmapping_read(char *page, char **start, off_t off, int count, int *eof, void *data);
int read_all_stats(char *page, char **start, off_t off, int count, int *eof, void *data);

/*
* np-mappings.c functions
*/
int mappings_init(void);
int def_input(struct sk_buff **skb, const struct net_device *netd);
struct sk_buff *def_output(const struct net_device *netd, struct sk_buff *skb);

/*
* API Functions
*/
extern int np_mapping_add(struct np_sw *nps);
extern int np_mapping_del(struct np_sw *nps);


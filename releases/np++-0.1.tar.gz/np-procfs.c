/*
Copyright (c) 2009, Matthew Jakeman
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the <organization> nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/netdevice.h>
#include <linux/kobject.h>
#include <linux/proc_fs.h>
#include <linux/version.h>
#include "np-mod.h"

#define __NO_VERSION__

struct proc_dir_entry *np_pde;
struct proc_dir_entry *np_ifcurmapping_pde;
struct proc_dir_entry *np_stats_pde;
struct np_int_map ifcm_pdes;

int np_procfs_init(void)
{
	int i = 0;
	struct net_device *list_dev;
	struct np_int_map *new_ifcm_pde;
	struct proc_dir_entry *stats_all_pde;

	INIT_LIST_HEAD(&ifcm_pdes.npil);

#ifdef DEBUG
	printk(KERN_INFO "Initialising NP++ sysfs entries\n");
#endif

#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,23)
	np_pde = proc_mkdir("np++", init_net.proc_net);
#else
	np_pde = proc_mkdir("np++", proc_net);
#endif
	np_ifcurmapping_pde = proc_mkdir("ifcurmappings", np_pde);
	np_stats_pde = proc_mkdir("stats", np_pde);

#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,23)
	for_each_netdev(&init_net, list_dev)
#else
	for(i = 1 ; (list_dev = dev_get_by_index(i)) != NULL ; i++)
#endif
    {
		/*
		* Register /proc ifcurmapping variables - add them to ifcm_pdes linked list
		*/
		/*
		* Create the proc entry and set the data pointer to it for use in the read and write functions
		*/
#ifdef DEBUG
		printk(KERN_INFO "Initialising Mapping For Interface %s\n", list_dev->name);
#endif
		new_ifcm_pde = kmalloc(sizeof(struct np_int_map), GFP_KERNEL);
		new_ifcm_pde->int_pde = create_proc_entry(list_dev->name , 0644, np_ifcurmapping_pde);
		new_ifcm_pde->int_pde->data = new_ifcm_pde;
		/*
		* Read and write functions
		*/
		new_ifcm_pde->int_pde->read_proc = ifcurmapping_read;
		new_ifcm_pde->int_pde->write_proc = ifcurmapping_write;
		new_ifcm_pde->int_pde->owner = THIS_MODULE;
		/*
		* Copy the device name to the list entry
		*/
		strcpy(new_ifcm_pde->name, list_dev->name);
		/*
		* Set the net_device in the list entry
		*/
		new_ifcm_pde->ndp = list_dev;
		/*
		* Set the current mapping to 0 (Default Mapping)
		*/
		new_ifcm_pde->map = 0;
		/*
		* Add new_ifcm_pde to the linked list
		*/
		list_add(&(new_ifcm_pde->npil), &(ifcm_pdes.npil));
    }

	stats_all_pde = create_proc_entry("all" , 0644, np_stats_pde);
	stats_all_pde->read_proc = read_all_stats;

	return 0;
}

int np_procfs_cleanup(void)
{
    struct np_int_map *del_ifcm_pde;
    struct list_head *pos, *q;

    /*
    * Clean up each interfaces proc_directory_entries
    */
    list_for_each_safe(pos, q, &ifcm_pdes.npil)
    {
        del_ifcm_pde = list_entry(pos, struct np_int_map, npil);
        remove_proc_entry(del_ifcm_pde->name, np_ifcurmapping_pde);
    }
    remove_proc_entry("stats", np_pde);
    remove_proc_entry("ifcurmappings", np_pde);
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,23)
    remove_proc_entry("np++", init_net.proc_net);
#else
    remove_proc_entry("np++", proc_net);
#endif


	/*
	* Remove Stats proc_directory_entries
	*/
	remove_proc_entry("all", np_stats_pde);
	return 0;
}

int ifcurmapping_write(struct file *filp, const char __user *buff, unsigned long len, void *data)
{
    struct np_int_map *ifcm_pde = (struct np_int_map *)data ;
    struct np_int_map *list_ifcm_pde;
    struct list_head *pos, *q;
    char from_buf[PROC_BUF_SIZE];

#ifdef DEBUG
    printk(KERN_INFO "ifcurmapping_write() called\n");
#endif

    /*
    * Read through linked list to match the list entry
    */
    list_for_each_safe(pos, q, &ifcm_pdes.npil)
    {
        list_ifcm_pde = list_entry(pos, struct np_int_map, npil);
        if(list_ifcm_pde == ifcm_pde)
        {
	  /*
	   * Copy the user input to the current mapping in the list entry that has been matched
	   */
	  if (copy_from_user(from_buf, buff, len))
	  {
	    return -EFAULT;
	  }
	  list_ifcm_pde->map = (u_char)simple_strtol(from_buf, NULL, 10);
	  return len;
        }
    }

	/*
    * No matching interface was found so return 0;
    */
	return 0;
}

/*
* Read the current mapping for a /proc/net/np++/ifcurmappings entry
*/
int ifcurmapping_read(char *page, char **start, off_t off, int count, int *eof, void *data)
{
	int len;
	struct np_int_map *ifcm_pde = (struct np_int_map *)data ;
    struct np_int_map *list_ifcm_pde;
    struct list_head *pos, *q;

#ifdef DEBUG
	printk(KERN_INFO "ifcurmapping_read() called\n");
#endif

    if (off > 0)
    {
        *eof = 1;
        return 0;
    }

	/*
	* Read through linked list and print out current mapping
	*/
    list_for_each_safe(pos, q, &ifcm_pdes.npil)
    {
        list_ifcm_pde = list_entry(pos, struct np_int_map, npil);
		if(list_ifcm_pde == ifcm_pde)
		{
			len = sprintf(page, "%d\n", ifcm_pde->map);
			*eof = 1;
		    return len;
		}
    }

	/*
	* No matching interface was found so return 0;
	*/
	return 0;
}

int read_all_stats(char *page, char **start, off_t off, int count, int *eof, void *data)
{
	int len;
    struct list_head *pos, *q;
    struct np_sw *nps;
	char *cat_str = kmalloc(4192, GFP_KERNEL);

#ifdef DEBUG
	printk(KERN_INFO "read_all_stats() called\n");
#endif

	len = sprintf(page, "NP++ All Stats\n\nPackets Sent : %ld\nPackets Received : %ld\nIncoming Packets Dropped : %ld\nOutgoing Packets Dropped : %ld\n\nNP++ Mapping Specific Stats :\n\n", np_stats.p_sent, np_stats.p_recvd, np_stats.p_in_dropped, np_stats.p_out_dropped);

	list_for_each_safe(pos, q, &np_phys_sw.npswl)
	{
		nps = list_entry(pos, struct np_sw, npswl);
		len += sprintf(cat_str, "%s :\n\nPackets Sent : %ld\nPackets Received : %ld\nIncoming Packets Dropped : %ld\nOutgoing Packets Dropped : %ld\n\n", nps->desc, nps->p_sent, nps->p_recvd, nps->p_in_dropped, nps->p_out_dropped);

		strcat(page, cat_str);
	}
	kfree(cat_str);
	*eof = 1;
	return len;
}
